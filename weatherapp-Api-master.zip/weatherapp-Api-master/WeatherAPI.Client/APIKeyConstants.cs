﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherAPI.Client
{
    public class ApiKeyConstants
    {
        public const string HeaderName = "X-Api-Key";
    }
}
