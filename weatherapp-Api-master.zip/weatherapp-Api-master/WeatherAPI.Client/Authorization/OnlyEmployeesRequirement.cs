﻿using Microsoft.AspNetCore.Authorization;

namespace WeatherAPI.Client
{
    public class OnlyEmployeesRequirement : IAuthorizationRequirement
    {
    }
}
