﻿using Microsoft.AspNetCore.Authorization;

namespace WeatherAPI.Client
{
    public class OnlyThirdPartiesRequirement : IAuthorizationRequirement
    {
    }
}
