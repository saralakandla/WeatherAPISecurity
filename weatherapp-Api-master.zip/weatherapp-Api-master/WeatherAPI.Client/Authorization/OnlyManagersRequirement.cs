﻿using Microsoft.AspNetCore.Authorization;

namespace WeatherAPI.Client
{
    public class OnlyManagersRequirement : IAuthorizationRequirement
    {
    }
}
